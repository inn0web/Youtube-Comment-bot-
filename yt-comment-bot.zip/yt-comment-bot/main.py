from ui.root_widget import RootWidget
import tkinter

if __name__ == "__main__":
    root = tkinter.Tk()
    RootWidget(root, 0, 0)
    root.mainloop()