import os
import time
import random
import json
from undetected_chromedriver import Chrome, ChromeOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
import typing

current_dir = os.getcwd()

class BotBase:
    def __init__(self, user_data_dir:str, state:dict, save_state:typing.Callable) -> None:
        self.s = state
        self.saveState = save_state
        self.driver:Chrome = self.create_driver(user_data_dir)


    def create_driver(self, user_data_dir:str) -> Chrome:
        options = ChromeOptions()
        driver = Chrome(options=options, driver_executable_path=f"{current_dir}/chromedriver.exe", user_data_dir=user_data_dir)
        return driver


    def send_text(self, text):
        action = ActionChains(self.driver)
        for letter in text:
            if letter == "\n":
                letter = Keys.SHIFT + Keys.ENTER
            action = action.send_keys(letter)
            action = action.pause(random.randint(75, 150)/1000)
        action.perform()


class CommentBot(BotBase):

    def __init__(self, user_data_dir: str, state: dict, save_state: typing.Callable) -> None:
        super().__init__(user_data_dir, state, save_state)
        self.driver.implicitly_wait(10)   
        self.driver.maximize_window() 
    

    def check_new_video(self, channel:str) -> typing.Union[str, int]:
        self.driver.get(channel)
        video_container = self.driver.find_elements(By.ID, "contents")
        if len(video_container) == 0:
            print("=> No videos found on channel.")
            return
        videos = video_container[0].find_elements(By.ID, "content")
        if len(videos) == 0:
            print("=> No videos found on channel.")
            return
        
        links = videos[0].find_elements(By.TAG_NAME, "a")
        if len(links) == 0:
            print("=> No videos found on channel.")
            return
        
        if self.s["channels_data"][channel] not in links[0].get_attribute("href"):
            print(f"=> New video found on channel: {channel}")
            return links[0].get_attribute("href")
        else:
            print(f"=> No new video found on channel: {channel}")
        

    def comment(self, video_link, text):
        self.driver.get(video_link)
        time.sleep(random.randint(5, 15))
        # print("=> Scrolling webpage")
        ActionChains(self.driver).scroll_by_amount(0, 300).perform()
        time.sleep(random.randint(5, 10))
        inputbox = self.driver.find_element(By.ID, "placeholder-area")
        # print("Element found..")
        # self.click_with_offset(inputbox)
        inputbox.click()
        time.sleep(random.randint(3, 6))
        self.send_text(text)
        time.sleep(random.randint(3, 6))
        self.driver.find_element(By.ID, "submit-button").click()


    def comment_on_new_videos(self):
        # add new channel to channels_Data if any
        for channel in self.s["channels"]:
            if channel not in self.s["channels_data"]:
                self.s["channels_data"][channel] = ""

        # remove channel from channels_Data
        for channel in list(self.s["channels_data"]):
            if channel not in self.s["channels"]:
                del self.s["channels_data"][channel]

        self.saveState()

        while self.s["running"]:
            for channel in self.s["channels"]:
                if not self.s["running"]:
                    break
                new_video = self.check_new_video(channel)
                if new_video: 
                    try:
                        self.comment(new_video, random.choice(self.s["comments"]))
                        print(f"=> Comment made on video: {new_video}")
                        self.s["channels_data"][channel] = new_video
                        self.saveState()
                    except:
                        print(f"=> Error commenting on video: {new_video}")
                sleep_after_action = random.randint(self.s["sleep_after_action_from"], self.s["sleep_after_action_to"])
                print(f"=> Sleeping for {sleep_after_action}")
                time.sleep(sleep_after_action)
        self.driver.quit()

class BotManager:

    def __init__(self) -> None:
        self.s = self.load_state()
        # saving the backup file
        self.saveState("data/backupstate.json")
    

    def load_state(self) -> dict:
        try:
            with open("data/state.json", "r") as file:
                return json.load(file)
        except:
            with open("data/backupstate.json", "r") as file:
                return json.load(file)
    

    def saveState(self, file_path:str="data/state.json") -> None:
        with open(file_path, "w") as file:
            json.dump(self.s, file)


    def comment_on_new_videos(self):
        self.s["running"] = True
        bot = CommentBot(f"{current_dir}/data/profile", self.s, self.saveState)
        bot.comment_on_new_videos()
        self.s["running"] = False
        print("=> Process stopped.")
