from ui.base_widget import BaseWidget
from threading import Thread


class StartCommentWidget(BaseWidget):

    def __init__(self, master, master_row, master_column, botManager) -> None:
        super().__init__(master, master_row, master_column)
        self.bot_manager = botManager

        # GUI Components
        self.Button("Start", 20, 10, 0, self.startAccountCreation)
        self.Button("Close", 20, 10, 2, self.closeProcess)


 
    def startAccountCreation(self):
        # Start Scraping
        if self.bot_manager.s["running"] == True:
            print("=> Process already running.")
            return
        thread = Thread(target=self.bot_manager.comment_on_new_videos)
        thread.start()


    def closeProcess(self):
        if self.bot_manager.s["running"] == False:
            print("=> No process running.")
        else:
            self.bot_manager.s["running"] = False
            print("=> Stopping running process.")
        

